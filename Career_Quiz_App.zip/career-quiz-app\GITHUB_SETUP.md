# GitHub + CodeSandbox Setup Guide

## Quick Setup Steps:

### 1. Create GitHub Repository
1. Go to [github.com](https://github.com) and sign in
2. Click "New repository" (green button)
3. Name it: `career-quiz-app`
4. Make it public
5. Initialize with README
6. Click "Create repository"

### 2. Upload Your Files
You can either:
- **Drag and drop** all files from your local folder into the GitHub web interface
- **Use GitHub Desktop** (easier for beginners)
- **Use git commands** (if you have git installed)

### 3. Import to CodeSandbox
1. Go to [codesandbox.io](https://codesandbox.io)
2. Click "Import from GitHub"
3. Paste your repository URL: `https://github.com/YOUR_USERNAME/career-quiz-app`
4. CodeSandbox will automatically set up everything!

## Alternative: Direct CodeSandbox Setup

If you prefer not to use GitHub:

1. Go to [codesandbox.io/s/new](https://codesandbox.io/s/new)
2. Select "React" template
3. Copy and paste each file manually:
   - Replace App.js with your App.js content
   - Create components folder
   - Add Quiz.js, Quiz.css, CareerRecommender.js, CareerRecommender.css
   - Update package.json to include react-router-dom

## Files to Upload to GitHub:

```
career-quiz-app/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Quiz.js
│   │   ├── Quiz.css
│   │   ├── CareerRecommender.js
│   │   └── CareerRecommender.css
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── index.css
├── package.json
└── README.md
```

## Your Repository URL Format:
`https://github.com/YOUR_USERNAME/career-quiz-app`

## CodeSandbox Import URL:
Just paste your GitHub repo URL into CodeSandbox import!
