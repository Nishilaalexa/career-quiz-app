import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Quiz from './components/Quiz';
import CareerRecommender from './components/CareerRecommender';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Quiz />} />
          <Route path="/career-recommender" element={<CareerRecommender />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
