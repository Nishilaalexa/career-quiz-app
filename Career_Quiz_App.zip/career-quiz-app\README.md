# Career Quiz App

A React-based interactive quiz application that helps users discover their ideal career stream through a series of thoughtfully designed questions.

## Features

- **10 Comprehensive Questions**: Each question has 4 multiple-choice options
- **Stream-Based Scoring**: Options are associated with Science, Commerce, Arts, and Design streams
- **Progress Tracking**: Visual progress bar showing quiz completion percentage
- **Interactive UI**: Beautiful animated gradient background and smooth transitions
- **Career Recommendations**: Personalized career suggestions based on quiz results
- **Responsive Design**: Works seamlessly on desktop and mobile devices

## How It Works

1. **Take the Quiz**: Answer 10 questions about your interests, preferences, and goals
2. **Track Progress**: See your progress with the visual progress bar at the top
3. **Navigate Easily**: "Next Question" button (disabled until you select an option)
4. **Get Results**: On completion, see your scores for each stream and get personalized career recommendations

## Streams

- **🔬 Science**: Research, experimentation, and scientific discovery
- **💰 Commerce**: Business, finance, and economic systems
- **🎨 Arts**: Creative expression, culture, and artistic pursuits
- **💻 Design**: Problem-solving through visual and functional design

## Installation

1. Navigate to the project directory:
   ```bash
   cd career-quiz-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm start
   ```

4. Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Project Structure

```
src/
├── components/
│   ├── Quiz.js              # Main quiz component
│   ├── Quiz.css             # Quiz styling
│   ├── CareerRecommender.js # Results and recommendations
│   └── CareerRecommender.css # Results styling
├── App.js                   # Main app with routing
├── App.css                  # Global app styles
├── index.js                 # Entry point
└── index.css                # Base styles
```

## Technologies Used

- React 18
- React Router DOM
- CSS3 with animations
- Modern ES6+ JavaScript

## Available Scripts

- `npm start` - Runs the app in development mode
- `npm build` - Builds the app for production
- `npm test` - Launches the test runner
- `npm eject` - Ejects from Create React App (one-way operation)
