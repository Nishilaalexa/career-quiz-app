import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './CareerRecommender.css';

const CareerRecommender = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { recommendedStream, scores } = location.state || {};

  const streamInfo = {
    Science: {
      emoji: "🔬",
      title: "Science Stream",
      description: "You have a natural curiosity for understanding how the world works and enjoy systematic investigation.",
      careers: [
        "Research Scientist",
        "Data Scientist",
        "Biotechnologist",
        "Environmental Scientist",
        "Medical Doctor",
        "Engineer",
        "Pharmacist",
        "Astronomer"
      ],
      color: "#4CAF50"
    },
    Commerce: {
      emoji: "💰",
      title: "Commerce Stream",
      description: "You have a keen interest in business, finance, and economic systems with strong analytical skills.",
      careers: [
        "Business Analyst",
        "Financial Advisor",
        "Investment Banker",
        "Entrepreneur",
        "Marketing Manager",
        "Accountant",
        "Economics Consultant",
        "Sales Director"
      ],
      color: "#FF9800"
    },
    Arts: {
      emoji: "🎨",
      title: "Arts Stream",
      description: "You are creative, expressive, and passionate about human culture and artistic expression.",
      careers: [
        "Graphic Designer",
        "Writer/Author",
        "Musician",
        "Actor/Actress",
        "Art Director",
        "Journalist",
        "Photographer",
        "Cultural Anthropologist"
      ],
      color: "#E91E63"
    },
    Design: {
      emoji: "💻",
      title: "Design Stream",
      description: "You combine creativity with problem-solving to create functional and beautiful solutions.",
      careers: [
        "UX/UI Designer",
        "Product Designer",
        "Web Designer",
        "Industrial Designer",
        "Architect",
        "Game Designer",
        "Fashion Designer",
        "Interior Designer"
      ],
      color: "#2196F3"
    }
  };

  const handleRetakeQuiz = () => {
    navigate('/');
  };

  if (!recommendedStream) {
    return (
      <div className="career-recommender-container">
        <div className="error-message">
          <h2>No quiz results found</h2>
          <button onClick={handleRetakeQuiz} className="retake-button">
            Take Quiz
          </button>
        </div>
      </div>
    );
  }

  const recommendation = streamInfo[recommendedStream];

  return (
    <div className="career-recommender-container">
      <div className="career-content">
        <div className="header-section">
          <div className="stream-icon" style={{ color: recommendation.color }}>
            {recommendation.emoji}
          </div>
          <h1 className="stream-title">{recommendation.title}</h1>
          <p className="stream-description">{recommendation.description}</p>
        </div>

        <div className="scores-section">
          <h3>Your Quiz Results</h3>
          <div className="scores-grid">
            {Object.entries(scores).map(([stream, score]) => (
              <div 
                key={stream} 
                className={`score-item ${stream === recommendedStream ? 'recommended' : ''}`}
                style={{ borderColor: streamInfo[stream].color }}
              >
                <span className="score-emoji">{streamInfo[stream].emoji}</span>
                <span className="score-stream">{stream}</span>
                <span className="score-value">{score}/10</span>
              </div>
            ))}
          </div>
        </div>

        <div className="careers-section">
          <h3>Recommended Career Paths</h3>
          <div className="careers-grid">
            {recommendation.careers.map((career, index) => (
              <div key={index} className="career-card">
                <span className="career-name">{career}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="actions-section">
          <button onClick={handleRetakeQuiz} className="retake-button">
            Retake Quiz
          </button>
        </div>
      </div>
    </div>
  );
};

export default CareerRecommender;
