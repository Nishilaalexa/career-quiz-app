import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Quiz.css';

const Quiz = () => {
  const navigate = useNavigate();
  
  const questions = [
    {
      id: 1,
      question: "What type of activities do you enjoy most?",
      options: [
        { text: "Conducting experiments and research", stream: "Science", emoji: "🔬" },
        { text: "Managing budgets and financial planning", stream: "Commerce", emoji: "💰" },
        { text: "Writing stories and creative expression", stream: "Arts", emoji: "🎨" },
        { text: "Creating digital interfaces and graphics", stream: "Design", emoji: "💻" }
      ]
    },
    {
      id: 2,
      question: "Which subject fascinates you the most?",
      options: [
        { text: "Biology and understanding life processes", stream: "Science", emoji: "🧬" },
        { text: "Economics and market trends", stream: "Commerce", emoji: "📈" },
        { text: "Literature and philosophy", stream: "Arts", emoji: "📚" },
        { text: "User experience and visual design", stream: "Design", emoji: "🎯" }
      ]
    },
    {
      id: 3,
      question: "What kind of work environment appeals to you?",
      options: [
        { text: "Laboratory or research facility", stream: "Science", emoji: "🥼" },
        { text: "Corporate office or trading floor", stream: "Commerce", emoji: "🏢" },
        { text: "Creative studio or cultural center", stream: "Arts", emoji: "🎭" },
        { text: "Design agency or tech company", stream: "Design", emoji: "🖥️" }
      ]
    },
    {
      id: 4,
      question: "Which skill would you like to develop further?",
      options: [
        { text: "Data analysis and hypothesis testing", stream: "Science", emoji: "📊" },
        { text: "Negotiation and business strategy", stream: "Commerce", emoji: "🤝" },
        { text: "Storytelling and artistic expression", stream: "Arts", emoji: "🎪" },
        { text: "Visual communication and prototyping", stream: "Design", emoji: "✏️" }
      ]
    },
    {
      id: 5,
      question: "What motivates you most in your work?",
      options: [
        { text: "Discovering new knowledge and solutions", stream: "Science", emoji: "🔍" },
        { text: "Building wealth and business success", stream: "Commerce", emoji: "💎" },
        { text: "Inspiring others through creativity", stream: "Arts", emoji: "✨" },
        { text: "Solving problems through design", stream: "Design", emoji: "🧩" }
      ]
    },
    {
      id: 6,
      question: "Which tools do you prefer working with?",
      options: [
        { text: "Microscopes and scientific instruments", stream: "Science", emoji: "🔬" },
        { text: "Spreadsheets and financial software", stream: "Commerce", emoji: "📋" },
        { text: "Paintbrushes and musical instruments", stream: "Arts", emoji: "🎵" },
        { text: "Design software and wireframing tools", stream: "Design", emoji: "🎨" }
      ]
    },
    {
      id: 7,
      question: "What type of problems do you enjoy solving?",
      options: [
        { text: "Complex scientific mysteries", stream: "Science", emoji: "🧪" },
        { text: "Financial puzzles and market challenges", stream: "Commerce", emoji: "💹" },
        { text: "Creative challenges and artistic expression", stream: "Arts", emoji: "🎨" },
        { text: "User experience and interface problems", stream: "Design", emoji: "📱" }
      ]
    },
    {
      id: 8,
      question: "Which achievement would make you most proud?",
      options: [
        { text: "Publishing groundbreaking research", stream: "Science", emoji: "📄" },
        { text: "Building a successful business", stream: "Commerce", emoji: "🚀" },
        { text: "Creating an inspiring work of art", stream: "Arts", emoji: "🖼️" },
        { text: "Designing an award-winning product", stream: "Design", emoji: "🏆" }
      ]
    },
    {
      id: 9,
      question: "How do you prefer to learn new things?",
      options: [
        { text: "Through experimentation and observation", stream: "Science", emoji: "👁️" },
        { text: "Through case studies and practical application", stream: "Commerce", emoji: "📖" },
        { text: "Through inspiration and creative exploration", stream: "Arts", emoji: "💡" },
        { text: "Through prototyping and user feedback", stream: "Design", emoji: "🔄" }
      ]
    },
    {
      id: 10,
      question: "What's your ideal career outcome?",
      options: [
        { text: "Making scientific breakthroughs", stream: "Science", emoji: "🌟" },
        { text: "Achieving financial independence", stream: "Commerce", emoji: "💰" },
        { text: "Leaving a creative legacy", stream: "Arts", emoji: "🎭" },
        { text: "Creating user-centered solutions", stream: "Design", emoji: "❤️" }
      ]
    }
  ];

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState(null);
  const [scores, setScores] = useState({
    Science: 0,
    Commerce: 0,
    Arts: 0,
    Design: 0
  });

  const handleOptionSelect = (option) => {
    setSelectedOption(option);
  };

  const handleNext = () => {
    if (selectedOption) {
      // Update scores
      setScores(prev => ({
        ...prev,
        [selectedOption.stream]: prev[selectedOption.stream] + 1
      }));

      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedOption(null);
      } else {
        // Quiz completed - determine highest scoring stream
        const updatedScores = {
          ...scores,
          [selectedOption.stream]: scores[selectedOption.stream] + 1
        };
        
        const recommendedStream = Object.keys(updatedScores).reduce((a, b) => 
          updatedScores[a] > updatedScores[b] ? a : b
        );
        
        // Navigate to career recommender with the recommended stream
        navigate('/career-recommender', { 
          state: { 
            recommendedStream,
            scores: updatedScores
          }
        });
      }
    }
  };

  const progressPercentage = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="quiz-container bg-gradient-animated-quiz">
      <div className="quiz-content">
        {/* Progress Bar */}
        <div className="progress-container">
          <div className="progress-bar">
            <div 
              className="progress-fill" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <span className="progress-text">
            Question {currentQuestion + 1} of {questions.length}
          </span>
        </div>

        {/* Question */}
        <div className="question-container">
          <h2 className="question-title">
            {questions[currentQuestion].question}
          </h2>
        </div>

        {/* Options */}
        <div className="options-container">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              className={`option-button ${selectedOption === option ? 'selected' : ''}`}
              onClick={() => handleOptionSelect(option)}
            >
              <span className="option-emoji">{option.emoji}</span>
              <span className="option-text">{option.text}</span>
              <span className="option-stream">{option.stream}</span>
            </button>
          ))}
        </div>

        {/* Navigation */}
        <div className="navigation-container">
          <button
            className={`next-button ${!selectedOption ? 'disabled' : ''}`}
            onClick={handleNext}
            disabled={!selectedOption}
          >
            {currentQuestion === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
